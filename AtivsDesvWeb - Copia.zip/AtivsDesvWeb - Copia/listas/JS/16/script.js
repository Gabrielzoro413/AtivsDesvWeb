function exibirStrings(array) {
    array.forEach(elemento => console.log(elemento));
}

const strings = ["Maçã", "Banana", "Laranja", "Uva"];
exibirStrings(strings);
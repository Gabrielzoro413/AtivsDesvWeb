document.getElementById("meuBotao").addEventListener("click", function () {
    document.getElementById("meuParagrafo").innerText = "O texto foi alterado!";
});
